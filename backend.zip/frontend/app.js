// ============================================================
// MERKIPAKI v2 — Frontend
// Los datos vienen de la API en /api/...
// que a su vez llama a Apify para obtener precios reales
// ============================================================

const API = "/api";

// ── Estado ───────────────────────────────────────────────────
let categoriaActual  = "todas";
let queryActual      = "";
let listaCompra      = [];
let filtroOfertasAct = "todas";
let toastTimer       = null;

function normalizar(texto) {
  return texto.toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

// ── Navegación ───────────────────────────────────────────────
function irA(id, enlace) {
  document.querySelectorAll(".pagina").forEach(p => p.classList.remove("activa"));
  document.getElementById("pagina-" + id).classList.add("activa");
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("activo"));
  enlace.classList.add("activo");
  return false;
}

// ── Comparador ───────────────────────────────────────────────
async function buscar() {
  queryActual = document.getElementById("busqueda").value.trim();
  await cargarProductos();
}

async function filtrarCategoria(cat, btn) {
  categoriaActual = cat;
  document.querySelectorAll("#pagina-comparador .chip").forEach(c => c.classList.remove("activo"));
  btn.classList.add("activo");
  await cargarProductos();
}

async function cargarProductos() {
  if (!queryActual) {
    document.getElementById("resultados").innerHTML = `
      <tr><td colspan="6" class="empty-state">
        <span class="empty-icon">🔍</span>
        <span>Busca un producto para ver los precios reales</span>
      </td></tr>`;
    document.getElementById("info-resultados").textContent = "";
    document.getElementById("fuente-datos").textContent = "";
    return;
  }

  // Aviso de carga — Apify puede tardar hasta 20 segundos
  document.getElementById("resultados").innerHTML = `
    <tr><td colspan="6" class="empty-state">
      <span class="spinner"></span>
      <span>Buscando precios reales en Mercadona y Carrefour… (puede tardar ~20 segundos)</span>
    </td></tr>`;
  document.getElementById("info-resultados").textContent = "";
  document.getElementById("fuente-datos").textContent = "";

  const params = new URLSearchParams({ q: queryActual });

  try {
    const res   = await fetch(`${API}/products?${params}`);
    if (!res.ok) throw new Error("Error del servidor");
    const datos = await res.json();

    renderTabla(datos.productos, datos.total);

    // Muestra de dónde vienen los datos
    const fuente = document.getElementById("fuente-datos");
    if (datos.fuente === "apify") {
      fuente.innerHTML = `<span class="fuente-apify">✅ Precios reales via Apify</span>`;
    } else if (datos.fuente === "cache") {
      fuente.innerHTML = `<span class="fuente-cache">⚡ Desde caché (actualizado hace poco)</span>`;
    } else {
      fuente.innerHTML = `<span class="fuente-fallback">⚠️ Datos de muestra (Apify no disponible)</span>`;
    }

    if (datos.aviso) toast("⚠️ " + datos.aviso);

  } catch (error) {
    console.error("Error:", error);
    document.getElementById("resultados").innerHTML = `
      <tr><td colspan="6" class="empty-state">
        <span class="empty-icon">⚠️</span>
        <span>No se pudo conectar. ¿Está el servidor corriendo?</span>
      </td></tr>`;
  }
}

function renderTabla(lista, total) {
  const info  = document.getElementById("info-resultados");
  const tbody = document.getElementById("resultados");

  if (!lista || lista.length === 0) {
    info.textContent = "";
    tbody.innerHTML = `
      <tr><td colspan="6" class="empty-state">
        <span class="empty-icon">🔍</span>
        <span>Sin resultados para "<strong>${queryActual}</strong>"</span>
      </td></tr>`;
    return;
  }

  info.textContent = `${total} resultados`;

  const ordenada = [...lista].sort((a, b) =>
    a.nombre !== b.nombre ? a.nombre.localeCompare(b.nombre) : a.precio - b.precio
  );

  let html = "";
  let prevNombre = "";

  ordenada.forEach(p => {
    if (prevNombre && p.nombre !== prevNombre) {
      html += `<tr class="fila-sep"><td colspan="6"></td></tr>`;
    }

    const imgHtml = p.imagen
      ? `<img src="${p.imagen}" class="producto-img" alt="${p.nombre}" onerror="this.style.display='none'" />`
      : "";

    html += `
      <tr class="${p.esMejorPrecio ? "fila-mejor" : ""}">
        <td class="celda-nombre">
          ${imgHtml}
          ${p.nombre}
          <span class="tag-cat">${p.categoria}</span>
        </td>
        <td><span class="super super-${normalizar(p.supermercado)}">${p.supermercado}</span></td>
        <td class="celda-marca hide-sm">${p.marca}</td>
        <td class="celda-unidad hide-sm">${p.unidad}</td>
        <td class="celda-precio">
          ${p.precio.toFixed(2)} €
          ${p.esMejorPrecio ? '<span class="tag-mejor">↓ mejor</span>' : ""}
        </td>
        <td>
          <button class="btn-add" onclick="añadirDesdeTabla('${p.nombre.replace(/'/g, "\\'")}', ${p.precio}, '${p.supermercado}')">
            + Lista
          </button>
        </td>
      </tr>`;

    prevNombre = p.nombre;
  });

  tbody.innerHTML = html;
}

// ── Ofertas ───────────────────────────────────────────────────
async function filtrarOfertas(super_, btn) {
  filtroOfertasAct = super_;
  document.querySelectorAll("#chips-ofertas .chip").forEach(c => c.classList.remove("activo"));
  btn.classList.add("activo");
  await cargarOfertas();
}

async function cargarOfertas() {
  const grid = document.getElementById("ofertas-grid");
  grid.innerHTML = `<div class="ofertas-empty"><span class="spinner"></span></div>`;

  const params = new URLSearchParams();
  if (filtroOfertasAct !== "todas") params.set("supermercado", filtroOfertasAct);

  try {
    const res   = await fetch(`${API}/offers?${params}`);
    if (!res.ok) throw new Error("Error");
    const datos = await res.json();
    renderOfertas(datos.ofertas);
    document.getElementById("badge-ofertas").textContent = datos.total;
  } catch (e) {
    grid.innerHTML = `<div class="ofertas-empty"><span class="empty-icon">⚠️</span><span>Error al cargar ofertas.</span></div>`;
  }
}

function renderOfertas(lista) {
  const grid = document.getElementById("ofertas-grid");
  if (!lista || lista.length === 0) {
    grid.innerHTML = `<div class="ofertas-empty"><span class="empty-icon">⭐</span><span>Sin ofertas.</span></div>`;
    return;
  }
  grid.innerHTML = lista.map(o => `
    <div class="oferta-card ${o.caducada ? "vencida" : ""}">
      <div class="oferta-top">
        <span class="oferta-emoji">${o.emoji}</span>
        <span class="oferta-pct">-${o.descuentoPct}%</span>
      </div>
      <div class="oferta-body">
        <p class="oferta-nombre">${o.nombre}</p>
        <p class="oferta-desc">${o.descripcion}</p>
        <span class="super super-${normalizar(o.supermercado)} oferta-super">${o.supermercado}</span>
      </div>
      <div class="oferta-precios">
        <span class="precio-antes">${o.precioAntes.toFixed(2)} €</span>
        <span class="precio-ahora">${o.precioAhora.toFixed(2)} €</span>
        <span class="precio-ahorro">ahorras ${o.ahorro.toFixed(2)} €</span>
      </div>
      <div class="oferta-footer">
        <span class="oferta-hasta ${o.caducada ? "vencida-txt" : ""}">
          ${o.caducada ? "⚠ Caducada" : "⏰ Hasta " + o.hasta}
        </span>
        <button class="btn-add" onclick="añadirDesdeTabla('${o.nombre.replace(/'/g, "\\'")}', ${o.precioAhora}, '${o.supermercado}')">
          + Lista
        </button>
      </div>
    </div>`
  ).join("");
}

// ── Lista de la compra ────────────────────────────────────────
function añadirDesdeTabla(nombre, precio, supermercado) {
  listaCompra.push({ nombre, precio, supermercado, comprado: false });
  renderLista();
  toast("✓ Añadido a la lista");
}

function añadirManual() {
  const elNombre = document.getElementById("input-manual");
  const elPrecio = document.getElementById("input-precio");
  const nombre   = elNombre.value.trim();
  const precio   = parseFloat(elPrecio.value) || 0;
  if (!nombre) { elNombre.focus(); return; }
  listaCompra.push({ nombre, precio, supermercado: "—", comprado: false });
  elNombre.value = elPrecio.value = "";
  elNombre.focus();
  renderLista();
}

function toggleComprado(i) {
  listaCompra[i].comprado = !listaCompra[i].comprado;
  renderLista();
}

function eliminar(i) {
  listaCompra.splice(i, 1);
  renderLista();
}

function vaciarLista() {
  if (!listaCompra.length) return;
  if (confirm("¿Vaciar toda la lista?")) { listaCompra = []; renderLista(); }
}

function renderLista() {
  const ul    = document.getElementById("lista-items");
  const total = document.getElementById("lista-total");
  const badge = document.getElementById("badge-lista");

  badge.textContent = listaCompra.length;
  badge.classList.toggle("oculto", listaCompra.length === 0);

  if (!listaCompra.length) {
    if (total) total.textContent = "Total: 0.00 €";
    ul.innerHTML = `<li class="empty-state lista-vacia"><span class="empty-icon">🧺</span><span>Tu lista está vacía.</span></li>`;
    return;
  }

  const suma      = listaCompra.reduce((s, i) => s + i.precio, 0);
  const pendiente = listaCompra.filter(i => !i.comprado).reduce((s, i) => s + i.precio, 0);
  if (total) total.textContent = `Total ${suma.toFixed(2)} € — Pendiente ${pendiente.toFixed(2)} €`;

  ul.innerHTML = listaCompra.map((item, i) => `
    <li class="${item.comprado ? "comprado" : ""}">
      <input type="checkbox" ${item.comprado ? "checked" : ""} onchange="toggleComprado(${i})" />
      <span class="item-nombre">${item.nombre}</span>
      <span class="item-super">${item.supermercado}</span>
      <span class="item-precio">${item.precio > 0 ? item.precio.toFixed(2) + " €" : "—"}</span>
      <button class="btn-del" onclick="eliminar(${i})">✕</button>
    </li>`
  ).join("");
}

// ── Toast ────────────────────────────────────────────────────
function toast(msg) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("visible"), 2500);
}

// ── Arranque ─────────────────────────────────────────────────
async function inicializarApp() {
  await Promise.all([cargarProductos(), cargarOfertas()]);

  document.getElementById("busqueda").addEventListener("input", async e => {
    queryActual = e.target.value.trim();
    // Pequeño delay para no llamar a Apify en cada tecla
    clearTimeout(window._searchTimer);
    window._searchTimer = setTimeout(() => cargarProductos(), 600);
  });

  document.getElementById("busqueda").addEventListener("keydown", e => {
    if (e.key === "Enter") { clearTimeout(window._searchTimer); buscar(); }
  });

  document.getElementById("input-manual").addEventListener("keydown", e => {
    if (e.key === "Enter") añadirManual();
  });
}

document.addEventListener("DOMContentLoaded", inicializarApp);

// Expone funciones al HTML
window.irA              = irA;
window.buscar           = buscar;
window.filtrarCategoria = filtrarCategoria;
window.filtrarOfertas   = filtrarOfertas;
window.añadirManual     = añadirManual;
window.vaciarLista      = vaciarLista;
window.añadirDesdeTabla = añadirDesdeTabla;
window.toggleComprado   = toggleComprado;
window.eliminar         = eliminar;
