require("dotenv").config();

const express  = require("express");
const cors     = require("cors");
const path     = require("path");

const productRoutes = require("./routes/products");
const offerRoutes   = require("./routes/offers");

const app  = express();
const PORT = process.env.PORT || 3000;

// Comprueba que el token de Apify está configurado
if (!process.env.APIFY_TOKEN) {
  console.warn("⚠️  APIFY_TOKEN no encontrado en .env — usando datos de respaldo");
}

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));

// Rutas
app.use("/api/products", productRoutes);
app.use("/api/offers",   offerRoutes);

app.get("/api", (req, res) => {
  res.json({
    nombre:  "Merkipaki API v2",
    apify:   !!process.env.APIFY_TOKEN,
    endpoints: [
      "GET /api/products?q=leche              → busca en Mercadona + Carrefour vía Apify",
      "GET /api/products?q=leche&supermercado=mercadona → solo Mercadona",
      "GET /api/products/cache                → ver cache actual",
      "GET /api/offers                        → ofertas de la semana",
      "GET /api/offers?activas=true           → solo vigentes",
      "GET /api/offers/:id                    → detalle de oferta",
    ],
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

app.listen(PORT, () => {
  console.log(`\n🛒 Merkipaki v2 corriendo en http://localhost:${PORT}`);
  console.log(`📦 API en http://localhost:${PORT}/api`);
  console.log(`🔑 Apify: ${process.env.APIFY_TOKEN ? "✅ configurado" : "❌ no configurado"}\n`);
});
