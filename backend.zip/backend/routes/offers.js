const express = require("express");
const router  = express.Router();
const { ofertas } = require("../data/fallback");

function caducada(hasta) {
  const [d, m, a] = hasta.split("/").map(Number);
  return new Date(a, m - 1, d) < new Date();
}

router.get("/", (req, res) => {
  const { supermercado, activas } = req.query;
  let resultado = ofertas;

  if (supermercado) {
    resultado = resultado.filter(o =>
      o.supermercado.toLowerCase() === supermercado.toLowerCase()
    );
  }
  if (activas === "true") {
    resultado = resultado.filter(o => !caducada(o.hasta));
  }

  const conCalculos = resultado.map(o => ({
    ...o,
    descuentoPct: Math.round((1 - o.precioAhora / o.precioAntes) * 100),
    ahorro:       +(o.precioAntes - o.precioAhora).toFixed(2),
    caducada:     caducada(o.hasta),
  }));

  res.json({ total: conCalculos.length, ofertas: conCalculos });
});

router.get("/:id", (req, res) => {
  const oferta = ofertas.find(o => o.id === parseInt(req.params.id));
  if (!oferta) return res.status(404).json({ error: "Oferta no encontrada" });
  res.json({
    ...oferta,
    descuentoPct: Math.round((1 - oferta.precioAhora / oferta.precioAntes) * 100),
    ahorro:       +(oferta.precioAntes - oferta.precioAhora).toFixed(2),
    caducada:     caducada(oferta.hasta),
  });
});

module.exports = router;
